## Table 4. Overall performance (mean ± SD over 30 seeds, 200 held-out days each)

| Metric | IoT-only | AI-only (tabular) | Blockchain-only | Integrated (tabular) | Proposed (neural) | NN + 2-opt | Demand-aware + 2-opt |
|---|---|---|---|---|---|---|---|
| Total cost per day | 24.19 ± 3.61 | 19.70 ± 1.39 | 24.19 ± 3.61 | 19.70 ± 1.39 | 14.96 ± 0.99 | 23.16 ± 3.47 | 17.78 ± 1.77 |
| Cost per 1000 units | 0.384 ± 0.065 | 0.311 ± 0.027 | 0.384 ± 0.065 | 0.311 ± 0.027 | 0.227 ± 0.015 | 0.368 ± 0.061 | 0.269 ± 0.027 |
| Demand satisfaction | 0.531 ± 0.024 | 0.535 ± 0.009 | 0.531 ± 0.024 | 0.535 ± 0.009 | 0.554 ± 0.005 | 0.531 ± 0.024 | 0.555 ± 0.005 |
| Mean delivery delay (h) | 0.213 ± 0.108 | 0.243 ± 0.100 | 0.213 ± 0.108 | 0.243 ± 0.100 | 0.024 ± 0.008 | 0.260 ± 0.108 | 0.024 ± 0.011 |
| Routing efficiency | 0.958 ± 0.018 | 0.907 ± 0.022 | 0.958 ± 0.018 | 0.907 ± 0.022 | 0.965 ± 0.008 | 1.000 ± 0.000 | 1.000 ± 0.000 |
| Customers served per day | 24.5 ± 2.3 | 11.0 ± 1.0 | 24.5 ± 2.3 | 11.0 ± 1.0 | 8.4 ± 0.4 | 24.5 ± 2.3 | 8.9 ± 0.4 |
| Decision latency (ms) | 0.319 ± 0.041 | 0.297 ± 0.026 | 0.437 ± 0.052 | 0.381 ± 0.037 | 1.453 ± 0.139 | 0.431 ± 0.058 | 0.153 ± 0.014 |

## Table 5. Proposed (neural) relative to each baseline (%; positive = proposed better; Holm-adjusted Wilcoxon p, 30 paired seeds)

| Baseline | Total cost per day | Cost per 1000 units | Demand satisfaction | Mean delivery delay (h) |
|---|---|---|---|---|
| IoT-only | +38.1 (p<0.001) | +40.9 (p<0.001) | +4.3 (p<0.001) | +88.5 (p<0.001) |
| Blockchain-only | +38.1 (p<0.001) | +40.9 (p<0.001) | +4.3 (p<0.001) | +88.5 (p<0.001) |
| AI-only (tabular) | +24.1 (p<0.001) | +26.9 (p<0.001) | +3.5 (p<0.001) | +89.9 (p<0.001) |
| Integrated (tabular) | +24.1 (p<0.001) | +26.9 (p<0.001) | +3.5 (p<0.001) | +89.9 (p<0.001) |
| NN + 2-opt | +35.4 (p<0.001) | +38.2 (p<0.001) | +4.3 (p<0.001) | +90.6 (p<0.001) |
| Demand-aware + 2-opt | +15.8 (p<0.001) | +15.5 (p<0.001) | -0.3 (p<0.001) | -2.3 (p=0.685) |

## Table 6. Integrated vs separate reward (mean ± SD; Holm-adjusted Wilcoxon p)

| Router | Model | Cost/day | Cost per 1000 units | Demand satisfaction | Delay (h) |
|---|---|---|---|---|---|
| tabular | Separate | 24.097 ± 2.136 | 0.568 ± 0.146 | 0.377 ± 0.070 | 0.713 ± 0.177 |
| tabular | Integrated | 19.700 ± 1.395 | 0.311 ± 0.027 | 0.535 ± 0.009 | 0.243 ± 0.100 |
| tabular | p (Holm) | <0.001 | <0.001 | <0.001 | <0.001 |
| neural | Separate | 19.792 ± 1.893 | 0.339 ± 0.047 | 0.498 ± 0.027 | 0.333 ± 0.114 |
| neural | Integrated | 14.962 ± 0.992 | 0.227 ± 0.015 | 0.554 ± 0.005 | 0.024 ± 0.008 |
| neural | p (Holm) | <0.001 | <0.001 | <0.001 | <0.001 |

## Table 7. Measured blockchain validation cost (wall-clock, mean ± SD over seeds)

| Configuration | Validation (ms) | Consensus + hashing (ms) | Total ledger (ms) | Decision latency (ms) | Ledger share of latency | Chains intact | Rejected plans |
|---|---|---|---|---|---|---|---|
| Blockchain-only | 0.077 ± 0.008 | 0.039 ± 0.003 | 0.116 | 0.437 | 26.6% | 30/30 | 0 |
| Separate (tabular) | 0.058 ± 0.005 | 0.035 ± 0.003 | 0.093 | 0.552 | 16.8% | 30/30 | 0 |
| Integrated (tabular) | 0.043 ± 0.004 | 0.036 ± 0.021 | 0.080 | 0.381 | 20.9% | 30/30 | 0 |
| Separate (neural) | 0.067 ± 0.008 | 0.046 ± 0.004 | 0.114 | 1.471 | 7.7% | 30/30 | 0 |
| Proposed (neural) | 0.038 ± 0.003 | 0.037 ± 0.004 | 0.076 | 1.453 | 5.2% | 30/30 | 0 |

## Table 8a. Tamper detection (30 seeds x 200 trials; single ledger copy)

| Attack | Detection rate |
|---|---|
| Edit a block, no re-hash | 100.0% |
| Edit and re-hash one block | 100.0% |
| Edit and re-hash the whole suffix (one copy) | 0.0% |

## Table 8b. Invalid-decision injection (10% corrupted proposals, 500 days, 30 seeds; 5 validators)

| Faulty validators | Invalid plans accepted | Valid plans rejected | Final trust (faulty) | Final trust (honest) | Faulty excluded (share of days) | Honest excluded |
|---|---|---|---|---|---|---|
| 0 of 5 | 0.0% | 0.0% | — | 1.000 | — | 0.0% |
| 1 of 5 | 0.0% | 0.0% | 0.918 | 1.000 | 1.0% | 0.0% |
| 2 of 5 | 0.0% | 0.0% | 0.897 | 1.000 | 0.9% | 0.0% |
| 3 of 5 | 100.0% | 0.0% | 1.000 | 0.876 | 0.0% | 0.8% |

## Table 9. Scaling (customers bootstrapped from the real pool; 5 seeds per size; mean)

| Customers | Vehicles | Q-table entries | Neural parameters | Cost/1000 units: tabular | neural | demand-aware + 2-opt | Neural vs heuristic |
|---|---|---|---|---|---|---|---|
| 10 | 1 | 199 | 1441 | 0.919 | 0.696 | 0.731 | +4.8% (1/5 seeds) |
| 20 | 1 | 513 | 1441 | 0.354 | 0.306 | 0.304 | -0.6% (2/5 seeds) |
| 40 | 3 | 1379 | 1441 | 0.324 | 0.235 | 0.276 | +14.9% (5/5 seeds) |
| 80 | 6 | 2893 | 1441 | 0.318 | 0.201 | 0.241 | +16.7% (5/5 seeds) |
| 160 | 12 | 6152 | 1441 | 0.332 | 0.206 | 0.258 | +20.3% (5/5 seeds) |

## Sensitivity (12 seeds, 100 days per level): cost per 1000 units

| Noise level | IoT-only | NN + 2-opt | Demand-aware + 2-opt | Integrated (tabular) | Proposed (neural) | Neural vs demand-aware (p) |
|---|---|---|---|---|---|---|
| 0% | 0.369 | 0.358 | 0.273 | 0.311 | 0.227 | +16.6% (p<0.001) |
| 10% | 0.370 | 0.359 | 0.275 | 0.315 | 0.229 | +16.5% (p<0.001) |
| 20% | 0.370 | 0.361 | 0.276 | 0.321 | 0.236 | +14.6% (p<0.001) |
| 30% | 0.372 | 0.363 | 0.281 | 0.326 | 0.241 | +14.3% (p<0.001) |
| 40% | 0.375 | 0.366 | 0.288 | 0.330 | 0.248 | +14.0% (p<0.001) |
